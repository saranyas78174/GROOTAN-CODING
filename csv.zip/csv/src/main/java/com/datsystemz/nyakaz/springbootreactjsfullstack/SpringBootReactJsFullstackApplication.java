package com.datsystemz.nyakaz.springbootreactjsfullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReactJsFullstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReactJsFullstackApplication.class, args);
	}

}
